/*
 *	Project Owner	: TU Chemnitz
 *	Project Name	: ASE Tutorial Unit-2
 *	File Name		: siu.c
 *	Author			: ASE Admin
 *  Created on		: 25 Feb 2024
 */

/* Includes ******************************************************************/
#include "siu.h"
#include "xpc56el.h"

/*
 * @brief	SIU pin configuration function
 *
 * @param	void
 * @retval	void
 */
void SIU_Init(void)
{

//task1
SIU.PCR[52].R = 0x100;

SIU.PCR[66].R = 0x2500 ; 

SIU.PCR[56].R = 0x200;
SIU.PCR[57].R = 0x200;
SIU.PCR[58].R = 0x200;
SIU.PCR[59].R = 0x200;
SIU.PCR[43].R= 0x200;
SIU.PCR[6].R = 0x200; 



//task2

SIU.PCR[53].R=0x100;
SIU.PCR[32].R=0x2500;

//task3 

//button
SIU.PCR[60].R=0x100; 
SIU.PCR[62].R=0X100;

//switchers
SIU.PCR[54].R=0x100;
SIU.PCR[55].R=0x100; 
SIU.PCR[52].R=0x100; 
SIU.PCR[53].R=0x100;
//output led
SIU.PCR[59].R=0x200; 
SIU.PCR[43].R=0x200; 
SIU.PCR[6].R=0x200; 



SIU.GPDI[59].R=0;
SIU.GPDI[43].R=0;
SIU.GPDI[6].R=0;


	// Configure all pins which are required for your task here

	/* TO-DO: your task implementations **************************************/


	/* Input pin configurations */

	//SIU.PCR[...].R = ...;




	/* Output pin configurations */

	//SIU.PCR[...].R = ...;




	/* Analog pin configurations */

	//SIU.PCR[...].R = ...;

	/*************************************************************************/
}
