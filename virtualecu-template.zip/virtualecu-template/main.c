/*
 *	Project Owner	: TU Chemnitz
 *	Project Name	: ASE Tutorial Unit-1
 *	File Name		: main.c
 *	Author			: ASE Admin
 *  Created on		: 25 Feb 2024
 */

/* Includes ******************************************************************/
#include "init.h"

#include "xpc56el.h"
#include "siu.h"
bool direction ; 
int counter; 
	
int LED_PCR[6] = {56,57,58,59,43,6};
 
/* Global variables **********************************************************/

// put any global variables you need here

/* Task-1 implementation *****************************************************/
void task_pot(int value){

int level = (value*6)/4096 ; 

for (int i=0 ; i<6 ; i++) {
   if (i<level){
   SIU.GPDO[LED_PCR[i]].R=1 ; 
   } else {
   SIU.GPDO[LED_PCR[i]].R=0 ; 
   }
   }
	/* TO-DO: your task implementations **************************************/

	/*************************************************************************/
}

/* Task-2 implementation *****************************************************/
void task_ldr(int value){

	int level=(value*6)/4096 ; 
	for (int j=0; j<level; j++) {
	if(j<level){
	SIU.GPDO[LED_PCR[j]].R=1 ; 
	} else {
	SIU.GPDO[LED_PCR[j]].R=0 ; 
	}
	}
	/* TO-DO: your task implementations **************************************/

	/*************************************************************************/
}

/* Task-3 implementation *****************************************************/
void task_counter(int value){

//task3 
	SIU.GPDI[59].R=0;
	SIU.GPDI[43].R=0;
	SIU.GPDI[6].R=0;
	

	if(value & 0x01)  	SIU.GPDO[59].R=1 ; 
	if(value & 0x02)  	SIU.GPDO[43].R=1 ; 
	if(value & 0x04)  	SIU.GPDO[6].R=1 ; 
	


	/* TO-DO: your task implementations **************************************/

	/*************************************************************************/
}

/*
 * @brief	Main program
 *
 * @param	void
 * @retval	int
 */

 bool checkDirection() {
	if(SIU.GPDI[60].R==0) {   //btn1
		direction=true; 
	} else if (SIU.GPDI[62].R==0){ //btn2
			direction=false; 
		} return 0; 
	}

int main(void) {

	PIT_ConfigureTimer(1,1000) ; 
	/* peripherals initialization, do not remove */
	peripheralsInit();


	/* TO-DO: your task implementations **************************************/


	/* Configure and start timer channels */	
    // PIT_ConfigureTimer(<channel>, <interval in milliseconds>);

	/*************************************************************************/

	/* main program */
	while(1){
		/* System function, do not remove */
		systemFunction();
		/* TO-DO: your task implementations **********************************/
        	
	int state_sw1 = SIU.GPDI[52].R ; 
	
	if (state_sw1 ==1) {
	int pot_value = (ADC0.CDR[5].R & 0x00000FFF);
	task_pot(pot_value) ; 
	} else {
	for (int i=0 ; i<6 ; i++) {
	SIU.GPDO[LED_PCR[i]].R=0 ; 
	}
	}
	  
	

//task2


int sw1_state=SIU.GPDI[52].R;
int sw2_state=SIU.GPDI[53].R;

if(sw1_state==0 && sw2_state==1) {
	int ldr_value = (ADC1.CDR[3].R & 0x00000FFF);
	task_pot(ldr_value); 
}else {
for(int j=0 ; j<6 ; j++) {
SIU.GPDO[LED_PCR[j]].R=0 ; 
}
}
//task3

checkDirection() ; 

if(SIU.GPDI[52].R==0 && SIU.GPDI[53].R==0 && SIU.GPDI[54].R==1) { 
	task_counter(counter); 
}

	}
	return 0; 
}




		/*********************************************************************/

		/* 10 ms OS delay */
		//osalThreadDelayMilliseconds(10UL);
	




/*
 * @brief	PIT timer channel 1 IRQ callback
 *
 * @param	void
 * @retval	void
 */
void PIT_Channel_1(void){
 
 while(SIU.GPDI[55].R==1) {
	if(direction) {
		counter= (counter + 1) % 8 ; //returns to 0
	} else{
		counter=(counter-1 +8) % 8; //returns to 7
	}
 }
	/* TO-DO: your task implementations **************************************/
	

	/*************************************************************************/
}


/*
 * @brief	PIT timer channel 2 IRQ callback
 *
 * @param	void
 * @retval	void
 */
void PIT_Channel_2(void){

	/* TO-DO: your task implementations **************************************/


	/*************************************************************************/
}


/*
 * @brief	PIT timer channel 3 IRQ callback
 *
 * @param	void
 * @retval	void
 */
void PIT_Channel_3(void){

	/* TO-DO: your task implementations **************************************/


	/*************************************************************************/
}
