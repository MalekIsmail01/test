
#ifndef CAN_LLD_CFG_H
#define CAN_LLD_CFG_H

#include "can_lld.h"

// kept for compatibility with real ECU

extern CANConfig can_config_cfg0;

#endif // CAN_LLD_CFG_H
